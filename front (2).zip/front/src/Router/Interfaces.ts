export interface RouterProps{
  routes: RoutesProps[],
  defaultComponent?: React.ComponentType<any> // eslint-disable-line @typescript-eslint/no-explicit-any
}

export interface RoutesProps{
  path: string,
  Component: React.ComponentType<any> // eslint-disable-line @typescript-eslint/no-explicit-any
}

export interface RouteProps{
  routeParams?: RouteParamsProps,
}

export interface RouteParamsProps{
  [key: string]: string | number
}

export interface LinkProps {
  to: string;
  target?: string;
  [key: string]: string | undefined;
}