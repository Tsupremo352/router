import { Router } from './Router/Router';
import { Suspense } from 'react';
import { RoutesProps } from './Router/Interfaces';

const routes: RoutesProps[] = [];

export default function App(){
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <Router routes={routes} />
    </Suspense>
  );
}