import { EVENTS, BUTTONS } from './Consts';
function navigateTo(href){
  window.history.pushState({}, '', href);
  const navigationEvent = new Event(EVENTS.PUSHSTATE);
  window.dispatchEvent(navigationEvent);
}
function Link({ to, target, ...props }){
  const handleClick = (e)=>{
    const isMainEvent = e.button === BUTTONS.PRIMARY;
    const isModifiedEvent = e.metaKey || e.altKey || e.ctrlKey || e.shiftKey;
    const isManageableEvent = target === undefined || target === '_self';
    if (isMainEvent && !isModifiedEvent && isManageableEvent){
      e.preventDefault();
      navigateTo(to);
    }
  }
  return(
    <a onClick={handleClick} href={to} target={target} {...props} />
  )
}
export { Link };