import { Link } from './Link';
import './NotFound.css';

export default function NotFound(){
  return (
    <div className='ts-not-found'>
      <div className='ts-not-found-card'>
        <h1>404</h1>
        <span>Not Found</span>
        <Link to="/">Go to Main Page</Link>
      </div>
    </div>
  )
}