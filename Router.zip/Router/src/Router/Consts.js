'use strict';
const EVENTS = {
  PUSHSTATE: 'pushstate',
  POPSTATE: 'popstate',
};
const BUTTONS = {
  PRIMARY: 0,
};
export { EVENTS, BUTTONS };